package com.usian.mq;



import com.usian.mapper.LocalMessageMapper;
import com.usian.pojo.LocalMessage;
import com.usian.utils.JsonUtils;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.core.RabbitTemplate.ConfirmCallback;
import org.springframework.amqp.rabbit.core.RabbitTemplate.ReturnCallback;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * 功能：
 * 1、发送消息
 * 2、消息确认成功返回后修改Local_message(status:1)
 */
@Component
public class MQSender implements ReturnCallback, ConfirmCallback {
    @Autowired
    private  AmqpTemplate amqpTemplate;
    @Autowired
    private LocalMessageMapper localMessageMapper;
    /**
     * 确认回调
     */
    @Override
    public void confirm(CorrelationData correlationData, boolean ack, String cause) {
        System.out.println("///////////////////"+ack);
        if (ack){
            // 消息发送成功,更新本地消息为已成功发送状态或者直接删除该本地消息记录
            LocalMessage localMessage = new LocalMessage();
            String txNo = correlationData.getId();
            localMessage.setTxNo(txNo);
            localMessage.setState(1);
            localMessageMapper.updateByPrimaryKeySelective(localMessage);
        }
    }
    /**
     * 失败回调
     */
    @Override
    public void returnedMessage(Message message, int replyCode, String replyText, String exchange, String routingKey) {
        System.out.println("return message:"+message.toString()+ ",exchange:" + exchange + ",routingKey:" + routingKey);
    }

    /**
     * 发送消息
     * @param localMessage
     */
    public void sendMsg(LocalMessage localMessage) {
        RabbitTemplate rabbitTemplate = (RabbitTemplate) this.amqpTemplate;
        //失败回退
        rabbitTemplate.setReturnCallback(this);
        //确认回调
        rabbitTemplate.setConfirmCallback(this);
        //消息确认对象  id 用户消息确认成功后返回修改本地消息表的状态
        CorrelationData correlation = new CorrelationData(localMessage.getTxNo());
        rabbitTemplate.convertAndSend("order_exchange","order.add", JsonUtils.objectToJson(localMessage),correlation);
    }
}
