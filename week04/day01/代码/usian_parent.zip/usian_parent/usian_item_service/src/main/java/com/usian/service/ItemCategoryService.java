package com.usian.service;

import com.usian.pojo.TbItemCat;
import com.usian.utils.CatResult;

import java.util.List;


public interface ItemCategoryService {
    List<TbItemCat> selectItemCategoryByParentId(Long id);
    //查询首页商品分类
    CatResult selectItemCategoryAll();
}
