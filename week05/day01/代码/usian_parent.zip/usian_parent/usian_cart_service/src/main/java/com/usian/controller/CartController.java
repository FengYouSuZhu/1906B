package com.usian.controller;

import com.usian.pojo.TbItem;
import com.usian.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


@RequestMapping("/service/cart")
@RestController
public class CartController {
    @Autowired
    private CartService cartService;
    /**
     * 根据用户 ID 查询用户购物车
     */
    @RequestMapping("/selectCartByUserId")
    public Map<String, TbItem> selectCartByUserId(String userId){
    return  cartService.selectCartByUserId(userId);
    }
    /**
     * 将购物车缓存到 redis 中
     */
    @RequestMapping("/insertCart")
    public Boolean insertCart(@RequestBody Map<String, TbItem> cart,  String userId){
        return  cartService.insertCart(cart,userId);
    }
}
