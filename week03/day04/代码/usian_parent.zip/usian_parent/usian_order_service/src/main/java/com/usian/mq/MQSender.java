package com.usian.mq;



import com.usian.mapper.LocalMessageMapper;
import com.usian.pojo.LocalMessage;
import com.usian.utils.JsonUtils;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Correlation;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.core.RabbitTemplate.ConfirmCallback;
import org.springframework.amqp.rabbit.core.RabbitTemplate.ReturnCallback;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * 功能：
 * 1、发送消息
 * 2、消息确认成功返回后修改Local_message(status:1)
 */
@Component
public class MQSender implements ReturnCallback, ConfirmCallback {
    @Autowired
    private  AmqpTemplate amqpTemplate;
    @Autowired
    private LocalMessageMapper localMessageMapper;
    /**
     * 确认回调
     */
    @Override
    public void confirm(CorrelationData correlationData, boolean ack, String cause) {
        String id = correlationData.getId();
        if (ack){
            LocalMessage localMessage = new LocalMessage();
            localMessage.setTxNo(id);
            localMessage.setState(1);
            localMessageMapper.updateByPrimaryKeySelective(localMessage);
        }
    }
    /**
     * 失败回调
     */
    @Override
    public void returnedMessage(Message message, int replyCode, String replyText, String exchange, String routingKey) {
        System.out.println("return message:"+message.toString()+ ",exchange:" + exchange + ",routingKey:" + routingKey);
    }

    /**
     * 发送消息
     * @param localMessage
     */
    public void sendMsg(LocalMessage localMessage) {
        RabbitTemplate rabbitTemplate = (RabbitTemplate) this.amqpTemplate;

        rabbitTemplate.setMandatory(true);//开启消息发送失败回退
        rabbitTemplate.setReturnCallback(this);//失败回退
        rabbitTemplate.setConfirmCallback(this);//确认回调
        //消息确认对象  id 用户消息确认成功后返回修改本地消息表的状态
        CorrelationData correlation = new CorrelationData(localMessage.getOrderNo());
        rabbitTemplate.convertAndSend("order_exchange","order.add", JsonUtils.objectToJson(localMessage),correlation);
    }
}
