package com.usian.service;

import com.usian.mapper.TbOrderItemMapper;
import com.usian.mapper.TbOrderMapper;
import com.usian.mapper.TbOrderShippingMapper;
import com.usian.pojo.OrderInfo;
import com.usian.pojo.TbOrder;
import com.usian.pojo.TbOrderItem;
import com.usian.pojo.TbOrderShipping;
import com.usian.redis.RedisClient;
import com.usian.utils.JsonUtils;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.function.Predicate;

@Service
@Transactional
public class OrderServiceImpl implements OrderService {
    @Autowired
    private RedisClient redisClient;
    @Autowired
    private TbOrderMapper tbOrderMapper;
    @Autowired
    private TbOrderItemMapper tbOrderItemMapper;
    @Autowired
    private TbOrderShippingMapper tbOrderShippingMapper;
    @Autowired
    private AmqpTemplate amqpTemplate;

    @Value("${ORDER_ID_KEY}")
    private String ORDER_ID_KEY;
    @Value("${ORDER_ID_BEGIN}")
    private  Long ORDER_ID_BEGIN;
    @Value("${ORDER_ITEM_ID_KEY}")
    private String ORDER_ITEM_ID_KEY;

    @Override
    public Long insertOrder(OrderInfo orderInfo) {
        /************1、向订单表插入数据。********/
        TbOrder tbOrder = orderInfo.getTbOrder();
        if (!redisClient.exists(ORDER_ID_KEY)){
            //设置初始值
            redisClient.set(ORDER_ID_KEY,ORDER_ID_BEGIN);
        }
        //设置生成订单号
        Long orderId=redisClient.incr(ORDER_ID_KEY,1);
        tbOrder.setOrderId(orderId.toString());
        tbOrder.setPostFee("0");
        //1、未付款，2、已付款，3、未发货，4、已发货，5、交易成功，6、交易关闭
        tbOrder.setStatus(1);
        Date date = new Date();
        tbOrder.setCreateTime(date);
        tbOrder.setUpdateTime(date);
        tbOrderMapper.insertSelective(tbOrder);
        /************2、向订单明细表插入数据********/
        List<TbOrderItem> tbOrderItemList =
                JsonUtils.jsonToList(orderInfo.getOrderItem(),TbOrderItem.class);
        for (TbOrderItem tbOrderItem : tbOrderItemList) {
            //生成明细id
            Long incr = redisClient.incr(ORDER_ITEM_ID_KEY, 1);
            tbOrderItem.setId(incr+"");
            tbOrderItem.setOrderId(orderId.toString());
            //插入数据
            tbOrderItemMapper.insertSelective(tbOrderItem);
        }

        /************3、向订单明细表插入数据********/
        TbOrderShipping tbOrderShipping = orderInfo.getTbOrderShipping();
        tbOrderShipping.setOrderId(orderId.toString());
        tbOrderShipping.setCreated(date);
        tbOrderShipping.setUpdated(date);
        tbOrderShippingMapper.insertSelective(tbOrderShipping);

        //发送消息到mq，完成扣减库存和删除购物车中的商品
        amqpTemplate.convertAndSend("order_exchange","order.add",orderId);

        /************4、返回订单id********/
        return orderId;
    }
}
