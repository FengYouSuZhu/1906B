package com.usian.interceptor;

import com.usian.feign.SSOServiceFeignClient;
import com.usian.pojo.TbUser;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@Component
public class LoginInterceptor implements HandlerInterceptor {
    @Autowired
    private SSOServiceFeignClient ssoServiceFeignClient;
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
       //对用户的token做判断
        String token = request.getParameter("token");
        if (StringUtils.isBlank(token)){
            return false;
        }
        //token不为空，校验用户在redis中是否失效
        TbUser user = ssoServiceFeignClient.getUserByToken(token);
        if (user==null){
            return false;
        }
        return true;
    }
}
